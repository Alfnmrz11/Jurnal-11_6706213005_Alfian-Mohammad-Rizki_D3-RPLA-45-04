package com.company;

public class Tree <E extends Comparable<E>> {
    private Node<E> root;
    //konstruktor
    public Tree(){
        root=null;
    }
    //Bagian Insertion & pengecekan root
    public void insertNode(E insertValue){
        if (root==null){
            root=new Node<E>(insertValue);
            System.out.println(insertValue +" adalah root");
        }else{
            root.insert(insertValue);
        }
    }
    //Bagian Searching
    public void searchBTS(E key){
        boolean result = searchBTSHelper(root, key);

        if (result){
            System.out.println("Data " +key+ " ditemukan");
        }else{
            System.out.println("Data " +key+ " tidak ditemukan");
        }
    }

    public boolean searchBTSHelper(Node<E> node, E key){
        boolean result=false;

        if(node!=null){
            if(key.equals(node.getData())){
                result=true;
            }else if(key.compareTo(node.getData())<0){
                result=searchBTSHelper(node.getLeft(), key);
            }else{
                result=searchBTSHelper(node.getRight(), key);
            }
        }
        return result;
    }
}
